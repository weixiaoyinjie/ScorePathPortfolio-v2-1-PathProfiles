package com.scorepath.portfolio;
import android.app.Activity;
import android.content.Intent;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import android.os.Bundle;
import android.webkit.*;
import android.view.View;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private static final int PICK_SCREENSHOT=1974;
    private boolean picking=false;
    private final TextRecognizer recognizer=TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
    private final ExecutorService pool=Executors.newFixedThreadPool(3);
    @Override public void onCreate(Bundle state){ super.onCreate(state); web=new WebView(this); web.setBackgroundColor(0xff101619); setContentView(web);
        if(android.os.Build.VERSION.SDK_INT>=35){web.setOnApplyWindowInsetsListener((v,i)->{android.graphics.Insets x=i.getInsets(android.view.WindowInsets.Type.systemBars()); v.setPadding(x.left,x.top,x.right,x.bottom);return i;});}
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(false); s.setAllowFileAccess(false); s.setAllowContentAccess(false); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;} @Override public boolean shouldOverrideUrlLoading(WebView v,String url){return true;}});
        web.addJavascriptInterface(new HttpBridge(),"NativeHttp"); web.addJavascriptInterface(new ImageBridge(),"NativeImage"); web.loadUrl("file:///android_asset/index.html");
    }
    private void imageReply(boolean ok,String value){
        runOnUiThread(()->{picking=false;if(web!=null)web.evaluateJavascript("window.imageOcrReply("+ok+","+JSONObject.quote(value)+")",null);});
    }
    class ImageBridge {
        @JavascriptInterface public void pick(){runOnUiThread(()->{
            if(picking)return; picking=true;
            try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(i,PICK_SCREENSHOT);}
            catch(Exception e){imageReply(false,"无法打开相册，请手工输入比赛 ID");}
        });}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=PICK_SCREENSHOT)return;
        if(resultCode!=RESULT_OK||data==null||data.getData()==null){imageReply(false,"已取消选择");return;}
        try{InputImage img=InputImage.fromFilePath(this,data.getData());
            recognizer.process(img).addOnSuccessListener(t->imageReply(true,t.getText())).addOnFailureListener(e->imageReply(false,"文字识别失败，请裁剪截图或手工输入 ID"));
        }catch(Exception e){imageReply(false,"图片无法读取，请重选截图");}
    }
    class HttpBridge {
        @JavascriptInterface public void request(String id,String url,String headers,String body){pool.execute(()->{JSONObject result=new JSONObject(); HttpURLConnection c=null; try{
            URL u=new URL(url); if(!"https".equals(u.getProtocol())||u.getUserInfo()!=null)throw new IOException("HTTPS required");
            JSONObject h=new JSONObject(headers); if(h.has("x-apisports-key")&&!"v3.football.api-sports.io".equalsIgnoreCase(u.getHost()))throw new IOException("Invalid football host");
            c=(HttpURLConnection)u.openConnection(); c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(35000);c.setRequestMethod(body.isEmpty()?"GET":"POST");
            for(Iterator<String> it=h.keys();it.hasNext();){String k=it.next(); if(k.equalsIgnoreCase("Authorization")||k.equalsIgnoreCase("Content-Type")||k.equalsIgnoreCase("x-apisports-key"))c.setRequestProperty(k,h.getString(k));}
            if(!body.isEmpty()){c.setDoOutput(true);try(OutputStream out=c.getOutputStream()){out.write(body.getBytes(StandardCharsets.UTF_8));}}
            int code=c.getResponseCode(); if(code<200||code>=300){result.put("ok",false);result.put("status",code);result.put("error","HTTP "+code);}else{try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>8_000_000)throw new IOException("Response too large");out.write(b,0,n);}result.put("ok",true);result.put("body",out.toString("UTF-8"));}}
        }catch(Exception e){try{result.put("ok",false);result.put("error",e.getClass().getSimpleName()+": 请求失败");}catch(Exception ignored){}}finally{if(c!=null)c.disconnect();}
        String js="window.nativeReply("+JSONObject.quote(id)+","+JSONObject.quote(result.toString())+")";runOnUiThread(()->{if(web!=null)web.evaluateJavascript(js,null);});});}
    }
    @Override protected void onDestroy(){if(web!=null){web.removeJavascriptInterface("NativeHttp");web.removeJavascriptInterface("NativeImage");web.destroy();web=null;}recognizer.close();pool.shutdownNow();super.onDestroy();}
}
